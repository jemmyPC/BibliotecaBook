import { Component, OnInit } from '@angular/core';



@Component({
  selector: 'app-test-validator',
  templateUrl: './test-validator.component.html',
  styleUrls: ['./test-validator.component.scss']
})
export class TestValidatorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
