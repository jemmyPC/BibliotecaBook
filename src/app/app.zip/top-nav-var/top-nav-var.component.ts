import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-top-nav-var',
  templateUrl: './top-nav-var.component.html',
  styleUrls: ['./top-nav-var.component.scss']
})
export class TopNavVarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
