

export class Status {

    Id: number;
    status: string;
}


