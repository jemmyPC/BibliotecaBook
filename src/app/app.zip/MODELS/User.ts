


export class User {

        ID: number;
        Name: string;
        LastName: string;
        CURP: string;
        Email: string;
        UserName: string;
        Password: string;
        Quantity?: number;
        IsActive?: boolean;
       

}


