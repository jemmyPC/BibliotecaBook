

export class Book {
     Id: number
     ISBN: number
     Autor: string
     Title: string
     NumPages: number
     Edition: string
     Description: string
     Quantity: number

}
