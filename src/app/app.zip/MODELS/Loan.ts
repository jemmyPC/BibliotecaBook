export class Loan {
  [x: string]: any

  Id: number
  UserID: number
  DateCreate: number
  DateFinish: number
  StatusId: number
  Debt: number
  IdBook: number
  IsActive : boolean

}
